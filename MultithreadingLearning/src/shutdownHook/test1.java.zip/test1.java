public class test1 {
	public static void main(String[] args) throws InterruptedException{
		System.out.println("Starting");
		Thread.sleep(10000);
		System.out.println("Ending");
	}
}